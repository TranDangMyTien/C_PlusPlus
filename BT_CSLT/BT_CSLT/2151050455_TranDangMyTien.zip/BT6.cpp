// Bai thuc hanh chuong 2 bai6
#include <iostream>
#include <cassert>
using namespace std;
int main() {
	int n, sodao, tong;
	int so1, so2, so3;
	cout << "Nhap vao so nguyen co ba chu so : ";
	cin >> n;
    assert (n >= 100 && n <= 999);
	so3 = n % 10;
	so1 = n / 100;
	so2 = n / 10 % 10;
	tong = so1 + so2 + so3;
	sodao = so3 * 100 + so2 * 10 + so1;
	cout << "Tong ba chu so cua " << n << " la " << tong << endl;
	cout << " So dao nguoc cua " << n << " la " << sodao << endl;
	return 0;
}
