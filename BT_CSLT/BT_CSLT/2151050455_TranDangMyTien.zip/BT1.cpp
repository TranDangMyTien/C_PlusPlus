//Bai thuc hanh chuong 2 bai1
#include <iostream>
using namespace std;
int main () {
	double canh = 0.0;
	double dientich = 0.0;
	cout << "Nhap vao canh hinh vuong (cm) :";
	cin >> canh;
	dientich = canh * canh;
	cout << "Dien tich hinh vuong " << canh << "cm la :" << dientich << "cm^2" << endl;
	return 0;
}