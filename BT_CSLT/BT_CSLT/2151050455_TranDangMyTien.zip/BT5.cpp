// Bai thuc hanh chuong 2 bai5
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main() {
	double a, b, c;
	double p = 0.0;
	double dientich = 0.0;
	cout << "Nhap ba canh tam giac :";
	cin >> a>> b >> c;
	p = (a + b + c) / 2;
	dientich = sqrt(p * (p - a) * (p - b) * (p - c));
	cout << "Dien tich tam giac la : " << fixed << setprecision (2) <<dientich << endl;
	return 0;
}
