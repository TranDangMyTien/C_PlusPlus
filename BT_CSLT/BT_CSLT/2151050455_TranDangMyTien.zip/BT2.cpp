// Bai thuc hanh chuong 2 bai2
#include <iostream>
using namespace std;
int main() {
	double dai = 0.0;
	double rong = 0.0;
	double dientich = 0.0;
	cout << "Nhap vao chieu dai (cm) :";
	cin >> dai;
	cout << "Nhap vao chieu rong (cm) :";
	cin >> rong;
	dientich = dai * rong;
	cout << "Dien tich hinh chu nhat = " << dientich << endl;
	return 0;
}
