//Bai thuc hanh chuong 2 bai4
#include <iostream>
#include <string>
using namespace std;
int main() {
	const double pi = 3.141593 ;
	double bankinh = 0.0 ;
	double dientich= 0.0 ;
	double chuvi= 0.0 ;
	cout << "Nhap ban kinh hinh tron: ";
	cin >> bankinh;
	dientich = pi * bankinh * bankinh;
	cout << "Dien tich hinh tron la: " << dientich
		<< endl;
	chuvi = 2 * pi * bankinh;
	cout << "Chu vi hinh tron la: " << chuvi
		<< endl;
	return 0;
}
