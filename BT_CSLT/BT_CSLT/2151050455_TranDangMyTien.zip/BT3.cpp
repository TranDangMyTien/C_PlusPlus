//Bai thuc hanh chuong 2 bai3
#include <iostream>
#include <string>
using namespace std;
int main() {
	string ten = "";
	unsigned songay = 0;
	double tiencong = 0.0;
	double tienluong = 0.0;
	cout << "Ten nhan vien : ";
	cin >> ten;
	cout << "So ngay lam viec : ";
	cin >> songay;
	cout << "Tien cong (1 ngay ) ( nghin vnd ) : ";
	cin >> tiencong;
	tienluong = songay * tiencong;
	cout << "Tien luong cua " << ten << " la ( nghin vnd ) :" << tienluong << endl;
	return 0;
}
